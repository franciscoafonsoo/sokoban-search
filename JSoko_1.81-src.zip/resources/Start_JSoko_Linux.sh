#!/bin/sh

java -Xmx1024m -jar JSoko.jar

