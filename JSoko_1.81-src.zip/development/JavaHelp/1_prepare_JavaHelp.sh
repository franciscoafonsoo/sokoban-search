#/usr/bin/sh

##
## Delete the old download directory
##
rm -rf JavaHelp/

##
## Download web site if requested
##
#if [ $# -eq 1 ];
#then
if [[ "$1" == *download ]]
	then
		echo "Downloading online html pages"
		wget -nv --recursive --convert-links --html-extension --page-requisites --level=1 --trust-server-names --no-parent --no-cache 'http://www.sokoban-online.de/java-help.html?print=1'
		echo "Download completed"
	 	rename "s|www.sokoban-online.de|JavaHelp|g" "www.sokoban-online.de"
		if [[ "$1" == "justdownload" ]]
		then
			exit 0
		fi
	else
#	 	There is a backup folder so testing new scripts can be done without copying all files from the Internet everytime.
		echo "Unzipping backup file"
		unzip -q backup_of_html_files_for_quick_testing.zip
	fi
#fi

##
## Rename stylesheet file to work with JavaHelpIndexer
##
mv `find JavaHelp/typo3temp/stylesheet_731019e914.css*` "JavaHelp/typo3temp/stylesheet.css"
mv `find JavaHelp/typo3temp/stylesheet_b808cc7534.css?*` "JavaHelp/typo3temp/stylesheet2.css"

##
## 1. Remove the string %3Fprint=1.html from every html file
## 2. Remove unnecessary comments
## 3. Remove script lines
## 4. Rename stylesheet file to work with JavaHelpIndexer
## 5. Remove the string ?print=1 from every html file name
##
for file in `find ./JavaHelp -name "*.html"`; do
 sed -i 's|%3Fprint=1.html||g' $file;
 sed -i '/This website is powered/,/Information and contribution/d' $file;
 sed -i 's|<!--TYPO3SEARCH_begin-->||g' $file;
 sed -i 's|<!--TYPO3SEARCH_end-->||g' $file;
 sed -i 's|<script.*script>||g' $file;
 sed -i '/<script/,/<\/script/d' $file;				#scripting
 sed -i 's|<link rel="stylesheet" type="text/css" href="../typo3temp/stylesheet_b808cc7534.css%3F1425495363.css" media="all">||g' $file;
 sed -i 's|<link rel="stylesheet" type="text/css" href="../typo3conf/ext/cl_jquery_fancybox/fancybox2/jquery.fancybox.css%3F1425504248.css" media="screen">||g' $file;
 sed -i 's|stylesheet_731019e914.css%3F1425483808|stylesheet.css"|g' $file;
 sed -i 's|stylesheet_b808cc7534.css%3F1425495363|stylesheet2.css"|g' $file;
 sed -i 's|id="\(.*\)">|><a name="\1"></a>|g' $file;            #replace id="..." with <a name="..."></a>
 sed -i 's|id="\(.*\)">|><a name="\1"></a>|g' $file;            #must be done twice to get all (see: optimizer.html#RestrictingTheSearch)
 sed -i 's|<meta charset="iso-8859-1" />|<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />|g' $file;
 mv "$file" `echo $file | sed 's|\?print=1.html||g'`;
done;

##
## Remove any "(still in work)" from the release notes, that may still be there by mistake
##
sed -i 's|(still in work)||g' `find ./JavaHelp -name release-notes.html`;
sed -i 's|(work in progress)||g' `find ./JavaHelp -name release-notes.html`;

sed -i 's|(click image to see an enlarged version of the image) ||g' `find ./JavaHelp -name optimizer.html`;

sed -i 's|<a href="http://www.sokoban-online.de/fileadmin/_processed_/csm_JSoko_Optimizer_overview_01_6f3d96f3c2.png" class="lightbox" data-fancybox-group="lightbox200"><img src="../fileadmin/_processed_/csm_JSoko_Optimizer_overview_01_9299ef762b.png" width="616" height="414" alt="Optimizer overview"></a>|<img src="../fileadmin/_processed_/csm_JSoko_Optimizer_overview_01_9299ef762b.png" border="0" alt="Optimizer overview"/>|g' `find ./JavaHelp -name optimizer.html`;



##
## Remove unnecessary folders
##
rm -rf JavaHelp/typo3
rm -rf JavaHelp/typo3conf
rm -rf JavaHelp/fileadmin/100911_template

##
## Remove unnecessary files
## !in typo3temp the pics folder mustn't be deleted. It contains graphics that have automatically been resized by typo3!
##
rm JavaHelp/java-help.html
rm JavaHelp/typo3temp/*javascript*

# Copy needed Java help files
cp "additional needed java help files/helpset.hs" 	JavaHelp/helpset.hs
cp "additional needed java help files/toc.xml"    	JavaHelp/toc.xml
cp "additional needed java help files/JSoko-icon.gif"   JavaHelp/JSoko-icon.gif

# Start the indexer of the Java Help to support searching in the help:
# index all files in /JavaHelp/help and store the database in the JavaHelp/JavaHelpSearch folder.
# To ensure search works when zipped to a jar change the folder first.
cd JavaHelp
java -jar ../"needed jars"/jhindexer.jar ./help/
cd ..






