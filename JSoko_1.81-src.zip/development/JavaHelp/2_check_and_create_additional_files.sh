#/usr/bin/sh

##
# Create the index file using the targets that have been specified in the table of contents.
##
createIndexFile() {
	indexfile=./JavaHelp/index.xml
	echo "<?xml version='1.0' encoding='ISO-8859-1'?>" 				     	     >  $indexfile
	echo '<index version="2.0">' 								     >> $indexfile
	for target in `grep "target" JavaHelp/toc.xml | sed 's|.*target=\"\([^\"]*\).*|\1|'`; do
		echo -e '\t<indexitem text="'$target'"  target="'$target'" />' >> $indexfile

	  grep -q 'target="'$target'"' JavaHelp/map.jhm
	  	if [[ "$?" -ne "0" ]]; then
			echo -e "\nTarget: >$target< of toc file not found in map.jhm!"
		fi

	done
	echo "</index>" >> $indexfile

	echo "Index file created."
}

##
# Create the map file
##
createMapFile() {
	mapfile=./JavaHelp/map.jhm

	echo  "<?xml version='1.0' encoding='ISO-8859-1'?>"  >  $mapfile
	echo  " "										     >> $mapfile
	echo  '<map version="1.0">' 						 >> $mapfile

	for file in `find ./JavaHelp -name "*.html"`; do
	  
	  # example: help/jsoko/installation.html should become the target: jsoko.installation
	  fileURL=`echo $file | sed 's|./JavaHelp/||g'`
	  target=`echo $fileURL | sed 's|help/\(.*\).html|\1|g' | sed 's|/|.|g'`
	  formatedTarget=`printf "%-40s" \"$target\"`

	  echo -e '\t<mapID target='$formatedTarget' url="'$fileURL'" />'		     >> $mapfile

	  # create targets for every anchor in the file specified with: name="..."
	  # since more than on anchor may occur per line first ensure that every anchor is in its own line.
	  for fragmentID in `sed 's|<a name=|\n<a name=|g' $file | grep "<a name=" | sed 's|.*<a name="\([^"]*\).*|\1|g'`; do
	    fileURLWithFragmentID=`echo "$fileURL#$fragmentID"`
	    targetWithFragmentID=`printf "%-40s" \"$target.$fragmentID\"`

	    if [[ $fragmentID != content ]]; then   #content is default anchor by Typo3 and can be ignored
	      echo -e '\t<mapID target='$targetWithFragmentID' url="'$fileURLWithFragmentID'" />'    >> $mapfile
        fi
	  done	  

	  # add empty line before targets for the next file are added.
	  echo " "										         			>> $mapfile

	done

	# Icon shown top left in the window and in the task bar for help.
	echo -e '\t<mapID target="JSokoIcon"   url="JSoko-icon.gif" />'     >> $mapfile
	echo "</map>" 										                >> $mapfile

	echo "Map file created."
}

##
# Checks whether all files linked to in the map file exist
##
checkMapUrls() {
	# search string url= and remember all characters until a " appears. Then delete everything except the remembered part => output the url
	for file in `grep "url" JavaHelp/map.jhm | sed 's|.*url=\"\([^\"]*\).*|\1|'`; do

	# check whether the url coontains a fragment identifier like optimizer.html#OptimizerLog (where OptimizerLog is the identifier)
	if [[ "$file" == *#* ]]; then

	    fileUrl=`echo "$file" | sed 's|\(.*\)#.*|\1|g'`
	    fragmentID=`echo "$file" | sed 's|.*#\(.*\)|\1|g'`

	    if [ ! -f JavaHelp/"$fileUrl" ]; then
		    #The target of the map file targets a file that isn't there!
		    echo "File: JavaHelp/$fileUrl not found!"
	    else
		 # check whether the html file contains a anchor corresponding to the fragment identifier
		 grep -q 'name="'$fragmentID'"' JavaHelp/"$fileUrl"
       	    	 if [[ "$?" -ne "0" ]]; then
		 	echo "Fragment identifier >$fragmentID< not in file JavaHelp/$fileUrl!"
	    	fi
	    fi
	
	else
		if [ ! -f JavaHelp/"$file" ]; then
		    #The target of the map file targets a file that isn't there!
		    echo "File: JavaHelp/$file not found!"
		fi
	fi
	done

	echo "Checking of map file URLs finished."
}

##
# Checks whether all help targets used in the JSoko coding exist in the map file
##
checkTargets() {
	for file in `find '../../src/de/sokoban_online/jsoko/' -name "*.java"`; do
	  for target in `grep "enableHelpKey" $file | sed 's|[^\"]*\"\([^\"]*\).*|\1|'`; do
	    grep -q 'target="'$target'"' JavaHelp/map.jhm
       	    if [[ "$?" -ne "0" ]]; then
		echo -e "\nTarget: >$target< not found in map.jhm!"
		echo "Target is used in file: $file"
	        grep "enableHelpKey" $file | grep $target  		#display the coding where the target is used
	    fi
 	  done
	done

	echo "Checking of targets in java files finished."
}

oldIFS=$IFS  #Save current setting
IFS=$'\n'    #the urls may contain spaces which is problem because "for" splits at a space.

# Check urls and targets
createMapFile
createIndexFile
checkMapUrls
checkTargets

IFS=$oldIFS  #restore old setting
