#/usr/bin/sh
# Copy "table of content"-file - it may have been changed manually for testing
cp "additional needed java help files/toc.xml" JavaHelp/toc.xml
# Copy needed Java help files
cp "additional needed java help files/helpset.hs" JavaHelp/helpset.hs
# Open the Java Help
$(java -jar "needed jars"/hsviewer.jar -helpset `pwd`/JavaHelp/helpset.hs)
